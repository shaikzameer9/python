def main():
    
    # List of string 
    listOfStrings = ['MAHE' , 'SOIS', 'MANIPAL', 'MIT']
    
    # Print the List
    print(listOfStrings)
    
    #check if element exist in list using 'in'
    if 'SOIS' in listOfStrings :
        print("Yes, 'SOIS' found in List : " , listOfStrings)
    else:
    	print("'SOIS' not found")
    
    
    
main()