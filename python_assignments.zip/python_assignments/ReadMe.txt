1.The text files must be in the same folder to perform operations. 
2.Also they are created using the code itself. You will get to know as you proceed.
3.I have given some comments and references to understand better.
4. Q.5 and Q.6 are not included yet. I couldn't find relavant answers. I will look at them post dinner.
5. I have used Python 3.6 IDLE to check the codes. You can use anyone but make sure it supports Python 3.