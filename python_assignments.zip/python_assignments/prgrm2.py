'''square of a number'''
num = float(input("Enter number: "))
mul = float(num*num)
print("Square of a given number is:",mul)