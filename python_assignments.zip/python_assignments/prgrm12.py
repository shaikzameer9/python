'''area of circle,triangle,square using lambda function '''
area = lambda radius : 3.14*radius*2
print("area of the circle:")
print(area(4))
areat = lambda h,b : h*b
print("area of the triangle:")
print(areat(2,3))
areas = lambda a : a*a
print("area of the square:")
print(areas(9))